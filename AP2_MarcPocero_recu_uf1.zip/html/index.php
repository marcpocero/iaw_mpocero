<!DOCTYPE html>
<html lang="es">
  <head>
    <title> Login </title>
    <meta charset="UTF-8" >
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1">
    <link rel="stylesheet" href="estilos.css">
  </head>
  <body>
    <form action="validar.php" method="post">
      <h2> Login </h2>
      <input type="text" placeholder="&#128272; Usuario" name="usuario">
      <input type="password" placeholder="&#128272; Contrasena" name="clave">
      <input type="submit" value="Ingresar">
    </form>
  </body>
  </html>
