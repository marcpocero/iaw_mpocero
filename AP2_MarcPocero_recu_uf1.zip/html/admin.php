<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Admin</title>
		<link rel="stylesheet" href="css/reset.css">
		<link rel="stylesheet" href="css/styles.css">
	</head>
	<body>
		<nav>
			<ul class="especial">
				<table>
					<th><li><a href="index.php">Login</a></li></th>
					<th><li><a href="incidencies.php">Incidencias</a></li></th>
					<th><li><a href="historic.php">Historico</a></li></th>
					<th><li><a href="dashboard.php">Dashboard</a></li></th>
				</table>
			</ul>
		</nav>
		<table>
		<tr>
			<th>
				<h2>Historial:</h2>
			</th>
			<th>
				<?php
					$salida = shell_exec('./history.sh');
						echo "<pre>$salida</pre>";
				?>
		  </th>
		</tr>
		<tr>
			<th><h1>Gestion de usuarios</h1></th>
			<th></th>
		</tr>
		</table>
	</body>
</html>
