<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<title>IAW - AP1</title>
		<link rel="stylesheet" href="css/reset.css">
		<link rel="stylesheet" href="css/styles.css">
	</head>
	<body>
		<nav>
			<ul class="especial">
				<table>
					<th>
						<li>
							<a href="cerrar_session.php">Cerrar Sesión</a>
						</li>
					</th>
					<th>
						<li>
							<a href="incidencia/registro.php">Incidéncias</a>
						</li>
					</th>
					<th>
						<li>
							<a href="historic.php">Histórico</a>
						</li>
					</th>
					<th>
						<li>
							<a href="registro.php">Administrar</a>
						</li>
					</th>
				</table>
			</ul>
		</nav>
<div id="chart_div" style="width: 600px; height: 180px;"></div>

<table>
	<th></th>
	<th></th>
	<th></th>
	<th></th>
	<th></th>
</table>

<div class="ticketstotal">
      <div class="tile-stats">
        <div class="icon">
					<i class="fa fa-ticket"></i>
				</div>

				<?php
					$conection=mysqli_connect("localhost", "root", "marcpocero", "AP2");
				  $query = "SELECT count(*) as total from incidencies";
				  $resultado=mysqli_query($conection, $query);
					$data=mysqli_fetch_assoc($res);
						echo "Total de incidencias: ".$data['total']
				?>
<br>
				<?php
					$conection=mysqli_connect("localhost", "root", "marcpocero", "AP2");
					$query = "SELECT count(*)/(SELECT count(*) from incidencies)* 100 as percentage from incidencies where estat='Abierta'";
					$resultado=mysqli_query($conection, $query);
					$data=mysqli_fetch_assoc($resultado);
						echo "Porcentajes por hacer: ".$data['percentage']
				?>

<br>
				<?php
					$conection = mysqli_connect("localhost", "root", "marcpocero", "AP2");
				if ($conection->connect_error) {
					die("Conexion fallida: " . $conection->connect_error);
				}
					$sql = "SELECT usuari,count(*)/(SELECT count(*) from incidencies)* 100 as percentage from incidencies group by usuari";
					$resultado = $conection->query($sql);
				if ($resultado->num_rows > 0) {
				while($row = $resultado->fetch_assoc()) {
						echo "<tr><td>" . $row["usuari"]. "</td><td>" . $row["percentage"] . "</td><td>";
				}
						echo "</table>";
				}else {
						echo "0 resultados";
				}
					$conection->close();
				?>
<br>
				<?php
					$conection=mysqli_connect("localhost", "root", "marcpocero", "AP2");
					$query = "SELECT estat as estat from incidencies";
					$resultado=mysqli_query($conection, $query);
					$data=mysqli_fetch_assoc($resultado);
						echo "Estat: ".$data['estat']
				?>
		</div>
    </div>
	</body>
</html>
