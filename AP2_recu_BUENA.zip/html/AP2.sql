DROP DATABASE IF EXISTS AP2;
CREATE DATABASE IF NOT EXISTS AP2;
USE AP2;

DROP TABLE IF EXISTS incidencies;
CREATE TABLE incidencies (
id INT NOT NULL AUTO_INCREMENT,
descripcio VARCHAR(80),
tipus VARCHAR(80),
usuari VARCHAR(15),
estat VARCHAR(15),
data DATE,
PRIMARY KEY (id)
)ENGINE=innodb;

DROP TABLE IF EXISTS usuaris;
CREATE TABLE usuaris (
id INT NOT NULL AUTO_INCREMENT,
usuari VARCHAR(15),
contrasenya VARCHAR(15),
rol VARCHAR(15),
PRIMARY KEY (id)
)ENGINE=innodb;

INSERT INTO usuaris (usuari,contrasenya,rol) VALUES
('marc','1234','Admin'),
('jordi','1234','Cliente');

INSERT INTO incidencies (descripcio,tipus,usuari,estat) VALUES
('raton','Hardware','marc','Abierta'),
('wifi','Internet','marc','Cerrada');
