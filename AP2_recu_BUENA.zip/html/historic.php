<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Historic</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/styles.css">
  </head>
  <body>
    <nav>
      <ul class="especial">
        <table>
          <th>
            <li>
              <a href="cerrar_session.php">Cerrar sesion</a>
            </li>
          </th>
          <th>
            <li>
              <a href="incidencia/registro.php">Incidencias</a>
            </li>
          </th>
          <th>
            <li>
              <a href="dashboard.php">Dashboard</a>
            </li>
          </th>
          <th>
            <li>
              <a href="registro.php">Admin</a>
            </li>
          </th>
        </table>
      </ul>
    </nav>
    <table>
        <tr>
    <th>
      <h2>Historico incidencias cerradas</h2>
    </th>
  </tr>
  <tr>
    <td>
      <?php
$link = mysqli_connect("localhost", "root", "marcpocero", "AP2");
$sql = "SELECT * FROM `incidencies` WHERE `estat` = 'Cerrada' ;";
   $archivo = fopen("historic.txt", "w");
   if($result = mysqli_query($link, $sql)){
       if(mysqli_num_rows($result) > 0){
           while($row = mysqli_fetch_array($result)){
               fprintf($archivo, $row[0].";".$row[1].";".$row[2].";".$row[3].";".$row[4].";".$row[5].";".$row[6].PHP_EOL);
           }
       }
   }
   fclose($archivo);
$fp = fopen("historic.txt", "r");
   while (!feof($fp)){
     $linea = fgets($fp);
     echo "<p>".$linea."</p>";
   }
   fclose($fp);
      ?>
            </td>
  </tr>
    </table>
  </body>
</html>
